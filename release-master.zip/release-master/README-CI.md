# Continuous Integration How-to

Called from hack/jenkins/build.sh
